document.addEventListener('DOMContentLoaded', () => {
  const toggles = document.querySelectorAll('.us-vs-others__category-toggle');

  toggles.forEach(toggle => {
    toggle.addEventListener('click', () => {
      const category = toggle.getAttribute('aria-controls').replace('category-', '');
      const rows = document.querySelectorAll(`.us-vs-others__feature-row[data-category="${category}"]`);
      const isExpanded = toggle.getAttribute('aria-expanded') === 'true';

      toggle.setAttribute('aria-expanded', !isExpanded);
      rows.forEach(row => {
        row.style.display = isExpanded ? 'none' : '';
      });
    });
  });

  // Debug Font Awesome icons
  const icons = document.querySelectorAll('.us-vs-others__icon');
  if (icons.length === 0) {
    console.error('No Font Awesome icons found in comparison table');
  } else {
    console.log('Comparison table Font Awesome icons loaded:', icons.length);
  }
});